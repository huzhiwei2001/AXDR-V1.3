AXDR-V1.3版本LCD测试程序
板子上电后会在LCD屏幕中间打印AXDR  V1.3